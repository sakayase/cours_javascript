let people = ["Greg", "Mary", "Devon", "James"];

/*En utilisant une boucle, afficher le nom dans la console de chaque 
personne dans le groupe

Ecrire une commande qui enlève "Greg" du tableau
Ecrire une commande qui enlève "James" du tableau
Ecrire une commande qui ajoute "Matt" au début du tableau
Ecrire une commande qui ajoute votre nom à la fin du tableau

Faire une copie de ce tableau qui n'inclut pas "Mary" ou "Matt" 

Ecrire une commande qui donne la position de "Mary" dans le tableau

Ecrire une commande qui vérifie bien que "Foo" n'est pas dans le tableau

Supprimer "Devon" du tableau et ajouter à place "Elizabeth" et "Artie"

Créer une nouvelle variable qui s'appelle withBob et qui est égal au 
tableau people + "Bob"

Ecrire une commande qui affiche les noms du tableau à la suite,
mais avec un "-" entre chaque nom */

for (person in people) {
    console.log(people[person]);
}

people.splice(0,1);
console.log(people);

people.pop();
console.log(people);

people.unshift("Matt");
people.push("Simon")
console.log(people);

let newPeople = people.slice(2);

console.log(`Les nouveaux gens sont: ${newPeople}`);

console.log(`L\'index de Mary est : ${people.indexOf("Mary")}`);

if (people.includes("Foo")) console.log("Foo apparait dans le tableau");
else console.log('Foo n\'apparait pas dans le tableau');

let indexDevon = people.indexOf('Devon');
people.splice(indexDevon, 1, "Elizabeth","Artie" );

console.log(people);

let withBob = [];
withBob = people.slice(0, people.length);
withBob.push('Bob');

console.log(`withBob : ${withBob}`);

console.log(withBob.join("-"));